<!DOCTYPE html>
<html lang="en">
  <head>
    <title id="ttl">SQLMAP Web GUI</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./css/bootstrap.min.css">
    <link rel="stylesheet" href="./css/css.css">
    <script src="./js/jquery-2.1.4.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/sqlmap.js"></script>
  </head>
  <body>
    <br />
