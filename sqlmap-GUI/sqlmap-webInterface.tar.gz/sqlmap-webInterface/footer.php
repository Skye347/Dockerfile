
    <br/>
    <div class="footer" align="center">
        <br/>
        Want to learn more about <a href="http://sqlmap.org/" target="_blank">SQLMAP</a>, Visit the <a href="http://sqlmap.org/" target="_blank">Project Page!</a><br/>
        SQLMAP Web Operator Copyright &#0169; 2015, Coded By: HR, All rights reserved.<br/>
    </div>
    <br/><br/>
  </body>
</html>
